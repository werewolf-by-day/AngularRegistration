import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reg-component',
  templateUrl: './reg-component.component.html',
  styleUrls: ['./reg-component.component.css']
})
export class RegComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
