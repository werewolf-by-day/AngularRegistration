export class RegClass {
}
