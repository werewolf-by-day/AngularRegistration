import { Injectable } from '@angular/core';

@Injectable()
export class RegServiceService {

  constructor() { }

}
